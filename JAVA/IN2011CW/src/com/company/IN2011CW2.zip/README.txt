The program requires posts to be stored in a file called "res" in .txt format.
The client side requires an host address and a port number.